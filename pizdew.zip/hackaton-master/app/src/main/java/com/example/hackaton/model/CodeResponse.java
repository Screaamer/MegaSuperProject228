package com.example.hackaton.model;

public class CodeResponse {
    String token;

    public String getToken() {
        return token;
    }
}
